# v5.9 — Shared Locations + Date semantics + Sea-leg fields

Built on the v5.8 trunk. Three low-risk, mostly-additive changes. The riskier
flow-taxonomy rename is intentionally NOT here — it gets its own release next.

## 1. Shared location source of truth (`src/locations.ts` — NEW)

**Problem:** v5.8 had four separate `LOCATIONS` arrays (PurchaseOrders, SalesOrders,
Inventory, Shipments) that had drifted in spelling and conflicted on IDs (id 8 and
id 10 both meant Biedronka in different modules; Shipments had a "(SO/PO id)"
workaround). Cross-module references by ID could resolve to the wrong place.

**Fix (Option B — consolidate, keep IDs):**
- One shared `locations.ts`; all four modules import it.
- ALL existing IDs preserved → no seed-data reference changed, no saved
  localStorage data broken.
- Real conflicts resolved by aliasing: id 8 ≡ id 10 (Biedronka), id 9 ≡ id 11 (Lidl).
  Both resolve correctly; dropdowns hide the alias so each place shows once.
- Spelling unified (proper Polish diacritics).
- Added richer `type` taxonomy + `legacyType` so existing `LOCATION_TYPES[loc.type]`
  code keeps working. Each module maps the shared list onto the legacy field.
- Added 2 airports for the future air-export flow.

There is now ONE place to edit locations.

## 2. Date semantics — meaning + actual date (PO & SO)

**Problem:** the single date field was ambiguous (pickup? port arrival? warehouse?
client delivery?).

**Fix (additive):**
- Field relabelled "Expected delivery date" with a small `means:` dropdown under it.
  - PO: Pickup from supplier / Arrival at port / Arrival at our warehouse / Arrival at client
  - SO: Delivery to client / Pickup-ready at our side / Handover at relay / Loading at supplier / Arrival at destination port
- Separate `actual` date field (`actualAvailabilityDate` PO, `actualDeliveryDate` SO),
  blank until it happens — so you can compare promised vs actual.
- Existing field names unchanged → nothing downstream breaks.
- Seed rows updated with sensible means + actuals.

## 3. Sea-leg fields cleaned up (Shipments)

Per your note that vessel/voyage aren't fields you populate:
- **`vesselName` → `shippingLine`** — the field now holds the shipping COMPANY
  (e.g. MSC, Maersk, CMA CGM), which is what you actually track. Seed values
  updated ("MSC Atlas" → "MSC").
- **`voyageNumber` removed entirely** — from data, templates, and the form UI.
- Sea-leg form now shows: Container / Seal / Booking / BL / Shipping line.

## What was deliberately deferred

**Flow taxonomy rename → next release.** v5.8's flow codes (`EXP_CIF`, `IMP_DDP_DIR`…)
are load-bearing: `isDirectFlow()` detects direct-flow POs by the `EXP_*` / `*_DIR`
patterns to create the right inventory lots. Renaming needs the `isDirectFlow` fix
done in the same pass, and it deserves its own deploy so any regression is isolated.

**#6 From/To auto-fill improvement → next release** (with the flow rename).

## Files

**New:** `src/locations.ts`
**Modified:** `src/Inventory.tsx`, `src/PurchaseOrders.tsx`, `src/SalesOrders.tsx`, `src/Shipments.tsx`
**Unchanged:** App, Contacts, Dashboard, Finance, SOMarginCard, marginCalculations, operationalCosts, Settings, useLocalStoredState, shell_seed, index

## Safety

- All files balanced (braces/parens/brackets = 0).
- All local imports resolve.
- No seed IDs changed → existing localStorage data still resolves.
- New date fields additive → old records get default means + blank actuals.
- `vesselName`→`shippingLine` renamed consistently everywhere; `voyageNumber` fully removed.

## Deploy

Same workflow as the v5.8 deploy that worked: copy files into repo root, commit, push.
`vercel.json` / `.npmrc` / `package.json` unchanged.

## Test after deploy

- Open a PO and an SO in edit → new "Expected delivery date" + `means:` dropdown + "Actual" date render and save.
- Destination dropdowns: Biedronka appears once (not twice).
- Open the multimodal seed shipment (SHP-2026-0045) → sea leg shows "Shipping line: MSC", no Voyage field.
- Shipment from a PO still builds road→sea→road legs correctly.
