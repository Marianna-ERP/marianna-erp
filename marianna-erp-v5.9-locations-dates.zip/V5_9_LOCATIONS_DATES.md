# V5.9 — Shared Locations + Date semantics (on the v5.8 trunk)

Two architectural improvements applied to the working v5.8 baseline, chosen to be **low-risk and additive** so nothing v5.8 already does breaks.

## 1. Shared location source of truth (`src/locations.ts` — NEW)

**Problem fixed:** v5.8 had four separate `LOCATIONS` arrays (PurchaseOrders, SalesOrders, Inventory, Shipments). They had drifted in spelling ("Białski Owoc" vs "Bialski Owoc") and — more seriously — conflicted on IDs: id 8 and id 10 both meant Biedronka in different modules, and Shipments had a "(SO/PO id)" naming workaround to dodge the clash. Any cross-module reference by ID risked resolving to the wrong place.

**Fix (Option B — consolidate, keep IDs):**
- One shared `locations.ts` that all four modules import.
- **All existing IDs preserved** — no seed-data reference had to change, so zero risk of breaking existing POs / SOs / lots / shipments or anyone's saved localStorage data.
- The genuine conflicts are resolved by treating id 8 ≡ id 10 (Biedronka) and id 9 ≡ id 11 (Lidl) as aliases of the same real place. Both IDs resolve correctly; dropdowns hide the alias so Biedronka shows once.
- Spelling unified (proper Polish diacritics everywhere).
- Added a richer `type` taxonomy (RentedWarehouse / SupplierFacility / ClientFacility / Port / Airport / Customs / …) alongside the legacy single-word `type` ("OWN"/"PORT"/"CLIENT"/…). Existing UI code that does `LOCATION_TYPES[loc.type]` keeps working because each module maps the shared list back onto the legacy field.
- Added 2 airports (for the future air-export flow).

Each module now does:
```ts
import { LOCATIONS as SHARED_LOCATIONS } from "./locations";
const LOCATIONS = SHARED_LOCATIONS.map(l => ({ ...l, type: l.legacyType }));
```
So there is now **one place to edit locations** — the goal ChatGPT's own v5.5 changelog flagged ("destinations should move into a central Location Master").

## 2. Date semantics — meaning + actual date (PO & SO)

**Problem fixed:** the single `expectedDeliveryDate` (PO) / `deliveryDate` (SO) was ambiguous — pickup? port arrival? warehouse arrival? delivery to client? Different people read it differently.

**Fix (minimal, additive):**
- The date field is now labelled **"Expected delivery date"**, with a small **`means:`** dropdown under it so the date is never ambiguous:
  - PO options: Pickup from supplier / Arrival at port / Arrival at our warehouse / Arrival at client
  - SO options: Delivery to client / Pickup-ready at our side / Handover at relay / Loading at supplier / Arrival at destination port
- A separate **actual** date field (`actualAvailabilityDate` on PO, `actualDeliveryDate` on SO) — left blank until it actually happens, so you can compare promised vs actual.
- Existing field names (`expectedDeliveryDate`, `deliveryDate`) are unchanged, so nothing downstream breaks. New fields sit alongside.
- Seed POs/SOs were updated to carry sensible `means` values and, where already delivered, an actual date.

## What was deliberately NOT done

**Flow taxonomy rename — deferred to V6.** v5.8's flow codes (`EXP_CIF`, `IMP_DDP_DIR`, etc.) are *load-bearing*: the `isDirectFlow()` function detects direct-flow POs by the `EXP_*` / `*_DIR` patterns to create the right Inventory lots (a v5.8 feature). Renaming the codes now would silently break that. The richer flow taxonomy (with ownership-transfer metadata) belongs with the V6 journey-based Inventory work that actually consumes it, so it's deferred to there.

## Files

**New:** `src/locations.ts`
**Modified:** `src/Inventory.tsx`, `src/PurchaseOrders.tsx`, `src/SalesOrders.tsx`, `src/Shipments.tsx`
**Unchanged:** everything else (App, Contacts, Dashboard, Finance, SOMarginCard, marginCalculations, operationalCosts, Settings, useLocalStoredState, shell_seed, index)

## Deploy

Same as always: copy the files into your repo root, commit, push. `vercel.json` / `.npmrc` / `package.json` are unchanged from the v5.8 you already deployed successfully.

## Safety notes

- All files balanced (braces/parens/brackets).
- All local imports resolve.
- No seed-data IDs changed → existing localStorage data still resolves.
- New date fields are additive → old saved records simply get default `means` and blank actuals.
